@include('layouts.header')
@include('layouts.sidebar')
  <!-- Content Wrapper. Contains page content -->
  @yield('content')
  <!-- /.content-wrapper -->
@include('layouts.footer')  